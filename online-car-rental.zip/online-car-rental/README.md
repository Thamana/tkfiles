# Online-Car-Rental-System
Online Car Rental System
Online Car Rental System with Source Code is a PHP project that allows you to transact online booking for car rentals. The system is using PHP and MySQL.

The system is very straight forward. After you login as admin, you can create brand and add vehicles used for booking online.

Now both your car rental business and website can run smoothly, by accepting online reservations and managing your entire fleet, all from one single control panel. By offering highly-customizable booking system, your customers will be able to see vehicle availability, and make online reservations from your website, with just a few clicks.

The system also has testimonials and contact us page so the customer can give their feedback and contact the site owner.

The customer can register on the website and select which vehicle they’d like to rent.

Installation:
Extract the zip file under the htdocs folder.
Open phpMyAdmin and create a database called “carrental”.
Import the file named “carrental.sql” located under “db file” folder.
Open a browser and type http://localhost/car-rental/
The above is just an example. Change car-rental if you save it on different name after you extract the files.
Login information:
Admin

URL: http://localhost/car-rental/admin/
Username: admin
Password: admin

Customer

Register on the site using the URL below:
http://localhost/car-rental/#signupform


